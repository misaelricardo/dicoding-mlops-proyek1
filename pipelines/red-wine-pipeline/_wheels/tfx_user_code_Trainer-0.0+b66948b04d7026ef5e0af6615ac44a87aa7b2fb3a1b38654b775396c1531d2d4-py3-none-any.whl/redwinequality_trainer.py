import tensorflow as tf
import tensorflow_transform as tft 
from tensorflow.keras import layers
import os  
import tensorflow_hub as hub
from tfx.components.trainer.fn_args_utils import FnArgs

def _transformed_name(key):
    return key + '_xf'

def _build_keras_model():
    """Creates a DNN Keras model for classifying wine quality."""
    input_features = [
        tf.keras.layers.Input(name=_transformed_name(f), shape=(), dtype=tf.float32)
        for f in [
            'fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar',
            'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density',
            'pH', 'sulphates', 'alcohol'
        ]
    ]
    concatenated_features = tf.keras.layers.concatenate(input_features)
    
    x = concatenated_features
    for units in [10, 10]:
        x = tf.keras.layers.Dense(units, activation='relu')(x)
    
    output = tf.keras.layers.Dense(1, activation='sigmoid')(x)
    
    model = tf.keras.Model(input_features, output)
    
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model

def _input_fn(file_pattern, tf_transform_output, batch_size=32):
    transformed_feature_spec = (
        tf_transform_output.transformed_feature_spec().copy())
    
    dataset = tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=transformed_feature_spec,
        reader=tf.data.TFRecordDataset,
        label_key='quality'
    )
    
    return dataset

def run_fn(fn_args: FnArgs):
    """Train the model based on given args."""
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)
    
    train_dataset = _input_fn(fn_args.train_files, tf_transform_output, batch_size=40)
    eval_dataset = _input_fn(fn_args.eval_files, tf_transform_output, batch_size=40)
    
    model = _build_keras_model()
    model.fit(
        train_dataset,
        steps_per_epoch=fn_args.train_steps,
        validation_data=eval_dataset,
        validation_steps=fn_args.eval_steps
    )
    
    model.save(fn_args.serving_model_dir, save_format='tf')
